/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Observer;

/**
 *
 * @author fa20-bse-153
 */
public class observermain {
   
   public static void main(String[] args) {
      subject subject = new subject();

       hexa ob1 = new hexa(subject);
       octal ob = new octal(subject);
      

      System.out.println("First state change: 5");	
      subject.setState(5);
      System.out.println("Second state change: 20");	
      subject.setState(20);
      
      subject.deattach(ob1);
      System.out.println("Second state change: 5");	
      subject.setState(20);
   }
}

