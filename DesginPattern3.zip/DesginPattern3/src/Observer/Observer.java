/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Observer;

/**
 *
 * @author fa20-bse-153
 */
   public abstract class Observer {
   protected subject subject;
   public abstract void update();

    }
    

